-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.24-0ubuntu0.12.04.1 - (Ubuntu)
-- Server OS:                    debian-linux-gnu
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2012-10-14 08:09:12
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping structure for table datamining.candAUSTIN
CREATE TABLE IF NOT EXISTS `candAUSTIN` (
  `candidate_id` varchar(50) NOT NULL DEFAULT '0',
  `candidate_name` varchar(255) NOT NULL DEFAULT '0',
  `party` varchar(25) NOT NULL DEFAULT '0',
  `fec_election_year` varchar(25) NOT NULL DEFAULT '0',
  `candidate_state` varchar(25) NOT NULL DEFAULT '0',
  `candidate_office` varchar(25) NOT NULL DEFAULT '0',
  `current_district` varchar(25) NOT NULL DEFAULT '0',
  `incum_challenger_openseat` varchar(25) NOT NULL DEFAULT '0',
  `candidate_status` varchar(25) NOT NULL DEFAULT '0',
  `principle_campaign_committee_id` varchar(255) NOT NULL DEFAULT '0',
  `street_one` varchar(225) NOT NULL DEFAULT '0',
  `street_two` varchar(225) NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL DEFAULT '0',
  `state` varchar(25) NOT NULL DEFAULT '0',
  `zip` varchar(50) NOT NULL DEFAULT '0',
  `nicar_election_year` varchar(50) NOT NULL DEFAULT '0',
  `nicarid` varchar(50) NOT NULL DEFAULT '0',
  UNIQUE KEY `candidate_id` (`candidate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table datamining.candAUSTIN: ~1 rows (approximately)
/*!40000 ALTER TABLE `candAUSTIN` DISABLE KEYS */;
INSERT INTO `candAUSTIN` (`candidate_id`, `candidate_name`, `party`, `fec_election_year`, `candidate_state`, `candidate_office`, `current_district`, `incum_challenger_openseat`, `candidate_status`, `principle_campaign_committee_id`, `street_one`, `street_two`, `city`, `state`, `zip`, `nicar_election_year`, `nicarid`) VALUES
	('0', 'Lee Leffingwell', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '');
/*!40000 ALTER TABLE `candAUSTIN` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
