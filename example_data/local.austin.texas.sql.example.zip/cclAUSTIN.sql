-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.24-0ubuntu0.12.04.1 - (Ubuntu)
-- Server OS:                    debian-linux-gnu
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2012-10-14 08:09:33
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping structure for table datamining.cclAUSTIN
CREATE TABLE IF NOT EXISTS `cclAUSTIN` (
  `candidate_id` varchar(100) NOT NULL DEFAULT '0',
  `cand_election_year` varchar(50) NOT NULL DEFAULT '0',
  `fec_election_year` varchar(50) NOT NULL DEFAULT '0',
  `committee_id` varchar(100) NOT NULL DEFAULT '0',
  `committee_type` varchar(25) NOT NULL DEFAULT '0',
  `committee_designation` varchar(25) NOT NULL DEFAULT '0',
  `linkage_id` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table datamining.cclAUSTIN: ~1 rows (approximately)
/*!40000 ALTER TABLE `cclAUSTIN` DISABLE KEYS */;
INSERT INTO `cclAUSTIN` (`candidate_id`, `cand_election_year`, `fec_election_year`, `committee_id`, `committee_type`, `committee_designation`, `linkage_id`) VALUES
	('0', '0', '0', '1', '0', '0', '0');
/*!40000 ALTER TABLE `cclAUSTIN` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
