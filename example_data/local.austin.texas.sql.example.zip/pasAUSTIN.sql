-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.24-0ubuntu0.12.04.1 - (Ubuntu)
-- Server OS:                    debian-linux-gnu
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2012-10-14 08:10:08
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping structure for table datamining.pasAUSTIN
CREATE TABLE IF NOT EXISTS `pasAUSTIN` (
  `filer_id` varchar(100) NOT NULL DEFAULT '0',
  `amendment_indicator` varchar(25) NOT NULL DEFAULT '0',
  `report_type` varchar(25) NOT NULL DEFAULT '0',
  `primgen` varchar(25) NOT NULL DEFAULT '0',
  `microfilm` varchar(100) NOT NULL DEFAULT '0',
  `transaction_type` varchar(25) NOT NULL DEFAULT '0',
  `entity_type` varchar(25) NOT NULL DEFAULT '0',
  `contributor_name` varchar(512) NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL DEFAULT '0',
  `state` varchar(50) NOT NULL DEFAULT '0',
  `zip` varchar(50) NOT NULL DEFAULT '0',
  `employer` varchar(255) NOT NULL DEFAULT '0',
  `occupation` varchar(255) NOT NULL DEFAULT '0',
  `trans_date` varchar(50) NOT NULL DEFAULT '0',
  `amount` varchar(50) NOT NULL DEFAULT '0',
  `other_id` varchar(50) NOT NULL DEFAULT '0',
  `candidate_id` varchar(50) NOT NULL DEFAULT '0',
  `transaction_id` varchar(255) NOT NULL DEFAULT '0',
  `file_number` varchar(50) NOT NULL DEFAULT '0',
  `memo_code` varchar(50) NOT NULL DEFAULT '0',
  `memo_text` varchar(512) NOT NULL DEFAULT '0',
  `fec_record` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table datamining.pasAUSTIN: ~1 rows (approximately)
/*!40000 ALTER TABLE `pasAUSTIN` DISABLE KEYS */;
INSERT INTO `pasAUSTIN` (`filer_id`, `amendment_indicator`, `report_type`, `primgen`, `microfilm`, `transaction_type`, `entity_type`, `contributor_name`, `city`, `state`, `zip`, `employer`, `occupation`, `trans_date`, `amount`, `other_id`, `candidate_id`, `transaction_id`, `file_number`, `memo_code`, `memo_text`, `fec_record`) VALUES
	('1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
/*!40000 ALTER TABLE `pasAUSTIN` ENABLE KEYS */;
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
